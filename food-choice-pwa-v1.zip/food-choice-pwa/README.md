# 食在難選｜Android 優先 PWA

一款繁體中文美食決策工具，提供條件篩選、骰子、抽籤、轉盤、收藏與抽選歷史。無需帳號或後端，資料保存在使用者裝置。

## 本機預覽

PWA 必須透過 HTTPS 或 localhost 才能啟用 Service Worker。可在電腦安裝 Python 後，於專案資料夾執行：

```bash
python -m http.server 8000
```

再以瀏覽器開啟 `http://localhost:8000`。

## 免費部署到 GitHub Pages

1. 登入 GitHub，建立一個新的 Public repository，例如 `food-choice`。
2. 將本資料夾內所有檔案與 `assets` 資料夾上傳到 repository 根目錄。
3. 進入 repository 的 **Settings → Pages**。
4. 在 **Build and deployment** 選擇 **Deploy from a branch**。
5. Branch 選 `main`，資料夾選 `/(root)`，按 Save。
6. 等待 GitHub Pages 部署完成，使用 GitHub 顯示的 HTTPS 網址開啟。
7. 用 Android Chrome 開啟網址，從右上角選單選擇「安裝應用程式」或「新增至主畫面」。

若 repository 名稱不是 `<帳號>.github.io`，本專案使用相對路徑，適用於 `https://帳號.github.io/repository/`。

## Android 安裝

- 使用最新版 Chrome 開啟部署網址。
- 點頁面右上角「＋ 安裝」，或 Chrome 選單 →「安裝應用程式／新增至主畫面」。
- 安裝後可從桌面圖示啟動。
- 首次開啟需連網載入資源；完成快取後，主要抽選功能可離線使用。

## 資料與隱私

- 收藏與歷史紀錄使用 LocalStorage 儲存在本機瀏覽器。
- 清除瀏覽器網站資料或更換裝置，可能造成資料遺失。
- 第一版沒有帳號、雲端同步、定位、廣告或第三方資料傳輸。
- 預算與餐點價格是示意參考，不代表店家即時售價。

## 第一版已知限制

- 餐點資料為內建示範資料，非完整全台餐點／店家名錄。
- 情境與心情目前以條件交集篩選；某些條件組合可能沒有結果，可放寬條件。
- 「用餐對象」目前供使用者選擇記錄，尚未參與餐點排序。
- 不提供即時店家、營業時間、導航、外送平台連結或營養／過敏原保證。
- Google Fonts 若未快取或離線不可用，會退回系統字型；不影響主要功能。

## 專案檔案

- `index.html`：頁面結構
- `styles.css`：手機優先視覺與動畫
- `app.js`：餐點資料、篩選、遊戲、收藏與歷史
- `manifest.webmanifest`：PWA 安裝資訊
- `sw.js`：離線快取
- `assets/`：應用程式圖示
